﻿using Entities;
using LRCDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using LRCExceptions;
using System.Threading.Tasks;

namespace LRC_BAL
{
    public class lrcbal
    {
        private static bool ISValid(Service service)   //validation is done on inputs
        {
            StringBuilder errorMessage = new StringBuilder();
            bool valid = true;
            bool isServiceID = Regex.IsMatch(service.ServiceID, "^([S][R])([0-9]{4})$");
            if (!isServiceID)
            {
                valid = false;
                errorMessage.Append("ServiceId must be in correct format" + Environment.NewLine);
            }
            if (service.RequestDate >= DateTime.Now.Date)
            {
                valid = false;
                errorMessage.Append("Date must be Today's Date" + Environment.NewLine);
               valid = false;
            }

            bool isContactNo = Regex.IsMatch(service.ContactNo, "[7-9][0-9]{9}");
            if (!isContactNo)
            {
                valid = false;
                errorMessage.Append("Contact number must be valid" + Environment.NewLine);
            }

            bool isSerialNo = Regex.IsMatch(service.SerialNo, @"[0-9]{4}-[0-9]{4}-[0-9]{4}");
            if (!isSerialNo)
            {
                valid = false;
                errorMessage.Append("Serial number must be in correct format" + Environment.NewLine);
            }

            if (!valid)
            {
                throw new LrcExceptions(errorMessage.ToString());
            }

            return valid;
        }
        public static bool SubmitRequest(Service service)
        {
            bool RequestAdded = false;
            try
            {
                if (ISValid(service))   //Validation method is called
                {
                    lrcdal dal = new lrcdal();
                    RequestAdded = dal.AddRequest(service);   //dal  Addrequest method is accessed
                    return RequestAdded;
                }
            }
            catch (LrcExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return RequestAdded;
        }

        public static List<Service> GetAllRequest()
        {
            List<Service> serviceList=null;
            try
            {
                lrcdal DAL = new lrcdal();
                serviceList = DAL.GetAllRequestDAL();   //getallrequest in dal is accessed
            }
            catch (LrcExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return serviceList;
        }

    }
}
