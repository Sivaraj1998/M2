﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LRCExceptions
{
    public class LrcExceptions : ApplicationException
    {
        public LrcExceptions() : base()
        {

        }

        public LrcExceptions(string message) : base(message)
        {

        }

        public LrcExceptions(string message, Exception innerException)
            : base(innerException: innerException, message: message)
        {
        }
    }
}