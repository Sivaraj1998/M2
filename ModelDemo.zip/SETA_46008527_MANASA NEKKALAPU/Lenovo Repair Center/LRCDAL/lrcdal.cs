﻿using Entities;
using LRCExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace LRCDAL
{
    public class lrcdal
    {

        public bool AddRequest(Service service)
        {
            bool RequestAdded = false;
            SqlConnection objCon = null;

            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SERConnectionString"].ConnectionString); //connection is established
                SqlCommand objCom = new SqlCommand("[46008527].SubmitRequest", objCon);  
                objCom.CommandType = CommandType.StoredProcedure;   //input values are inserted using this
                
                SqlParameter objSqlParam_SeviceID = new SqlParameter("@ServiceID", service.ServiceID);
                SqlParameter objSqlParam_RequestDate = new SqlParameter("@RequestDate", service.RequestDate);
                SqlParameter objSqlParam_OwnerName = new SqlParameter("@OwnerName", service.OwnerName);
                SqlParameter objSqlParam_ContactNo = new SqlParameter("@ContactNo", service.ContactNo);
                SqlParameter objSqlParam_DeviceType = new SqlParameter("@DeviceType", service.DeviceType);
                SqlParameter objSqlParam_SerialNo = new SqlParameter("@SerialNo", service.SerialNo);
                SqlParameter objSqlParam_IssueDescription = new SqlParameter("@IssueDescription", service.IssueDescription);

                objCom.Parameters.Add(objSqlParam_SeviceID);   
                objCom.Parameters.Add(objSqlParam_RequestDate);
                objCom.Parameters.Add(objSqlParam_OwnerName);
                objCom.Parameters.Add(objSqlParam_ContactNo);
                objCom.Parameters.Add(objSqlParam_DeviceType);
                objCom.Parameters.Add(objSqlParam_SerialNo);
                objCom.Parameters.Add(objSqlParam_IssueDescription);

                objCon.Open();
                objCom.ExecuteNonQuery();  
                RequestAdded = true;
            }
            catch (LrcExceptions objSqlEx)
            {
                throw new LrcExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return RequestAdded;
        }

        public List<Service> GetAllRequestDAL()
        {
            List<Service> services= new List<Service>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SERConnectionString"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("[46008527].SelectRequest", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Service ser1 = new Service();
                    ser1.ServiceID= objDR[0] as string;
                    ser1.RequestDate =Convert.ToDateTime(objDR[1]);
                   ser1.OwnerName = (objDR[2]) as string;
                    ser1.ContactNo = (objDR[3]) as string;
                    ser1.DeviceType= (objDR[4]) as string;
                    ser1.SerialNo = (objDR[5]) as string;
                    ser1.IssueDescription = (objDR[6]) as string;
                    services.Add(ser1);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new LrcExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return services;
        }



    }
}
