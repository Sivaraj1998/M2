﻿using LRCExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using Entities;
using LRC_BAL;

namespace Lenovo_Repair_Center
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSubmitRequest_Click(object sender, RoutedEventArgs e)
        {

           
            SubmitRequest();  //both  submit and get request are called
            GetRequest();
        }

        private void SubmitRequest()
        {
            try
            {
                string serviceid;
                DateTime date;
                string ownername;
                string contactno;
                string devicetype;
                string Serialno;
                string issuedescription;

                //
                bool RequestAdded;
                //
                serviceid = txtId.Text;
                date = Convert.ToDateTime(txtRequestDate.Text);
                ownername = txtName1.Text;
                contactno = txtName2.Text;
                devicetype = ((ComboBoxItem)cbBlock.SelectedItem).Content.ToString();
                Serialno = txtName3.Text;
                issuedescription = txtName4.Text;
                //
                Service ser = new Service   // values are inserted into object and passed to BAL
                {
                    ServiceID = serviceid,
                    RequestDate = date,
                    OwnerName= ownername,
                    ContactNo= contactno,
                    DeviceType= devicetype,
                    SerialNo= Serialno,
                   IssueDescription =issuedescription
                };
                RequestAdded = lrcbal.SubmitRequest(ser);
                if (RequestAdded == true)
                {
                    MessageBox.Show("Request  added successfully.");
                }
                else
                {
                    MessageBox.Show("Request couldn't be added.");
                }
            }
            catch (LrcExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetRequest()   //displays service requests
        {
            try
            {
                List<Service> services= lrcbal.GetAllRequest();
                if (services != null)
                {
                    dgServices.ItemsSource = services;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (LrcExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
