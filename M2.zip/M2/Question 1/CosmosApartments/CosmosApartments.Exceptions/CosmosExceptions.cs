﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CosmosApartments.Exceptions;

namespace CosmosApartments.Exceptions
{
    public class CosmosExceptions : ApplicationException
    {
        public CosmosExceptions() : base()
        {

        }

        public CosmosExceptions(string message) : base(message)
        {

        }

        public CosmosExceptions(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
