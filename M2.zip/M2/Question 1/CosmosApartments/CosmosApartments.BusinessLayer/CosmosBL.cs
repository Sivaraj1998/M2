﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CosmosApartments.Entities;
using CosmosApartments.Exceptions;
using CosmosApartments.DataAccessLayer;

namespace CosmosApartments.BusinessLayer
{
    public class CosmosBL
    {
        CosmosDAL cosmosDAL = new CosmosDAL();

        public bool IsValid(Residents residents)
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;
            if (residents.FlatNo.ToString().Length != 3)
            {
                sb.Append("Flat No must be 3 Digit Value" + Environment.NewLine);
                isValid = false;
            }
                        
            if (residents.Date != DateTime.Now.Date)
            {
                sb.Append("Date must be Today's Date" + Environment.NewLine);
                isValid = false;
            }

            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }
            return isValid;
        }

        public int AddBL(Residents residents)
        {
            int no = 0;
            try
            {
                if (IsValid(residents))
                    no = cosmosDAL.Insert(residents);
            }
            catch (CosmosExceptions)
            {
                throw;
            }
            return no;
        }
    }
}
