﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CosmosApartments.Entities;
using CosmosApartments.Exceptions;
using System.Data.SqlClient;
using System.Configuration;


namespace CosmosApartments.DataAccessLayer
{
    public class CosmosDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlParameter incidentId = new SqlParameter("@IncidentID", System.Data.SqlDbType.Int);

        public int Insert(Residents residents)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("usp_InsertIncidents", conn);
                cmd.Parameters.AddWithValue("@FlatNo", residents.FlatNo);
                cmd.Parameters.AddWithValue("@Block", residents.Block);
                cmd.Parameters.AddWithValue("@Name", residents.Name);
                cmd.Parameters.AddWithValue("@Date", residents.Date);
                cmd.Parameters.AddWithValue("@ContactNo", residents.ContactNo);
                cmd.Parameters.AddWithValue("@IssueType", residents.IssueType);
                cmd.Parameters.AddWithValue("@Description", residents.Description);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                incidentId.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(incidentId);

                conn.Open();
                no = cmd.ExecuteNonQuery();
                residents.IncidentId = (int)incidentId.Value;

            }
            catch (CosmosExceptions)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }

            return no ;
        }
    }
}
