﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CosmosApartments.Entities;
using CosmosApartments.Exceptions;
using CosmosApartments.BusinessLayer;

namespace CosmosApartments.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        CosmosBL cosmosBL = new CosmosBL();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Residents residents = new Residents();
                txtDescription.SelectAll();
                string description = txtDescription.Selection.Text;
                if (txtFlatNo.Text == string.Empty ||
                    cbBlock.Text == string.Empty ||
                    txtResidentName.Text == string.Empty ||
                    txtIncidentDate.Text == string.Empty ||
                    txtContactNo.Text == string.Empty ||
                    cbIssueType.Text == string.Empty ||
                    description == string.Empty)
                {
                    MessageBox.Show("Please Enter All Fields");
                }

                else
                {
                    residents.FlatNo = Convert.ToInt32(txtFlatNo.Text);
                    residents.Block = Convert.ToChar(((ComboBoxItem)cbBlock.SelectedItem).Content.ToString());
                    residents.Name = txtResidentName.Text;
                    residents.Date = Convert.ToDateTime(txtIncidentDate.Text);
                    residents.ContactNo = txtContactNo.Text;
                    residents.IssueType = ((ComboBoxItem)cbIssueType.SelectedItem).Content.ToString();
                    txtDescription.SelectAll();
                    residents.Description = txtDescription.Selection.Text;
                    int no = cosmosBL.AddBL(residents);
                    if (no == 1)
                    {
                        MessageBox.Show("Incident Id: " + residents.IncidentId);
                        ClearAll();
                    }
                    else
                    {
                        MessageBox.Show("Record Not Inserted!");
                    }
                }

            }
            catch (CosmosExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void ClearAll()
        {
            txtFlatNo.Clear();
            cbBlock.SelectedIndex = -1;
            txtResidentName.Clear();
            txtIncidentDate.SelectedDate = null;
            txtContactNo.Clear();
            cbIssueType.SelectedIndex = -1;
            txtDescription.Document.Blocks.Clear();
        }
    }
}
