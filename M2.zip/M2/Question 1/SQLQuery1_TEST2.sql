﻿CREATE TABLE IncidentReports
(
	IncidentId INT NOT NULL IDENTITY(100,1),
	FlatNo INT NOT NULL,
	Block VARCHAR(1) NOT NULL,
	Name VARCHAR(30) NOT NULL,
	IncidentDate DATE,
	ContactNo VARCHAR(10),
	IssueType VARCHAR(15),
	Description VARCHAR(100)
)

SELECT * FROM IncidentReports


ALTER PROC usp_InsertIncidents
(
  @FlatNo INT,
  @Block VARCHAR(1),
  @Name VARCHAR(30),
  @Date DATE,
  @ContactNo VARCHAR(10),
  @IssueType VARCHAR(15),
  @Description VARCHAR(100),
  @IncidentID INT OUT
)
AS
BEGIN
	IF(@FlatNo <=0)
	BEGIN
		RAISERROR('Flat No cannot be null', 1, 1)
	END
	ELSE BEGIN
		INSERT INTO IncidentReports
		(FlatNo, Block, Name, IncidentDate, ContactNo, IssueType, Description)
		VALUES
		(@FlatNo, @Block, @Name, @Date, @ContactNo, @IssueType, @Description)
		SET @IncidentID = SCOPE_IDENTITY()
	END
END

DECLARE @IncidentID INT
EXEC usp_InsertIncidents 101,'D','Hariprasath', '07-08-2019','9944663644','Electrical','Hall Light is not working',@IncidentID OUT
PRINT @IncidentID

DECLARE @IncidentID INT
EXEC usp_InsertIncidents 101,'H','Hari', '07-08-2019','9944663644','Electrical','Hall Light is not working',@IncidentID OUT
PRINT @IncidentID

