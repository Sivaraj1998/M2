﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosmosIncidents
{
    public class Residents
    {
        public int IncidentId { get; set; }

        public int FlatNo { get; set; }

        public char Block { get; set; }

        public string Name { get; set; }

        public DateTime Date { get; set; }

        public string ContactNo { get; set; }

        public string IssueType { get; set; }

        public string Description { get; set; }
    }
}
