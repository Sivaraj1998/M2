﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;

namespace CosmosIncidents
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DB_186800Entities dboObj;

        public MainWindow()
        {
            dboObj = new DB_186800Entities();
            InitializeComponent();
        }

       
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgIncidents.ItemsSource = (from data in dboObj.IncidentReports
                                       where data.Block == "D"
                                       select new {
                                           data.IncidentId,
                                           data.FlatNo,
                                           data.Block,
                                           data.Name,
                                           data.IncidentDate,
                                           data.ContactNo,
                                           data.IssueType,
                                           data.Description}).ToList();
        }

    }
}
