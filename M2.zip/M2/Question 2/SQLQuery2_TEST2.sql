﻿
CREATE PROC usp_DisplayAllIncidents
AS
BEGIN
	SELECT * FROM IncidentReports
END

EXEC usp_DisplayAllIncidents WITH RESULT SETS
((
	IncidentId INT,
	FlatNo INT,
	Block VARCHAR(1),
	Name VARCHAR(30),
	IncidentDate DATE,
	ContactNo VARCHAR(10),
	IssueType VARCHAR(15),
	Description VARCHAR(100)
))